Netflix Clone – Separate Movie Posters

18 separate portrait poster images extracted from the generated cinematic
poster gallery.

Files:
1. interstellar.jpg
2. stranger-things.jpg
3. money-heist.jpg
4. wednesday.jpg
5. witcher.jpg
6. dark.jpg
7. squid-game.jpg
8. avengers.jpg
9. john-wick.jpg
10. inception.jpg
11. the-batman.jpg
12. top-gun.jpg
13. extraction.jpg
14. red-notice.jpg
15. army-of-dead.jpg
16. glass-onion.jpg
17. the-last-warrior.jpg
18. night-agent.jpg

Put these into your project:
netflix-clone/
└── images/
    ├── interstellar.jpg
    ├── stranger-things.jpg
    └── ...

Then use, for example:
<img src="images/interstellar.jpg" alt="Interstellar">
