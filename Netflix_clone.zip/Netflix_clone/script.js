// ============================================
// MOBILE MENU
// ============================================

const menuBtn = document.getElementById("menuBtn");

const mobileMenu = document.getElementById("mobileMenu");

menuBtn.addEventListener("click", () => {

    mobileMenu.classList.toggle("active");

});


// Close mobile menu when clicking a link

document.querySelectorAll(".mobile-menu a").forEach(link => {

    link.addEventListener("click", () => {

        mobileMenu.classList.remove("active");

    });

});


// ============================================
// MOVIE SLIDER
// ============================================

function scrollMovies(rowId, direction) {

    const row = document.getElementById(rowId);

    const scrollAmount = 700;

    row.scrollBy({
        left: direction * scrollAmount,
        behavior: "smooth"
    });

}


// ============================================
// MOVIE MODAL
// ============================================

const modal = document.getElementById("movieModal");

const modalTitle = document.getElementById("modalTitle");

const modalDescription =
    document.getElementById("modalDescription");


function openMovie(movieName) {

    modalTitle.textContent = movieName;

    modalDescription.textContent =
        `Watch ${movieName}, an exciting movie filled with
        action, adventure, drama and unforgettable moments.
        Enjoy this cinematic experience.`;

    modal.classList.add("active");

    document.body.style.overflow = "hidden";
}


function closeMovie() {

    modal.classList.remove("active");

    document.body.style.overflow = "auto";

}


// Close modal when clicking outside

modal.addEventListener("click", (event) => {

    if (event.target === modal) {

        closeMovie();

    }

});


// ============================================
// PLAY MOVIE
// ============================================

function playMovie() {

    alert(
        "🎬 Starting movie...\n\nThis is a frontend Netflix clone."
    );

}


// ============================================
// MY LIST
// ============================================

function addToList() {

    alert(
        "✓ Movie added to My List!"
    );

}


// ============================================
// SEARCH
// ============================================

const searchInput =
    document.getElementById("searchInput");


searchInput.addEventListener("input", function () {

    const searchText =
        this.value.toLowerCase().trim();

    const movieCards =
        document.querySelectorAll(".movie-card");


    movieCards.forEach(card => {

        const movieName =
            card.getAttribute("onclick") || "";

        if (
            searchText === "" ||
            movieName.toLowerCase().includes(searchText)
        ) {

            card.style.display = "";

        } else {

            card.style.display = "none";

        }

    });

});


// ============================================
// ESCAPE KEY
// ============================================

document.addEventListener("keydown", (event) => {

    if (event.key === "Escape") {

        closeMovie();

    }

});


// ============================================
// NAVBAR BACKGROUND ON SCROLL
// ============================================

window.addEventListener("scroll", () => {

    const navbar =
        document.querySelector(".navbar");

    if (window.scrollY > 80) {

        navbar.style.background =
            "rgba(0,0,0,.95)";

    } else {

        navbar.style.background =
            "linear-gradient(to bottom, rgba(0,0,0,.95), rgba(0,0,0,.7), transparent)";

    }

});